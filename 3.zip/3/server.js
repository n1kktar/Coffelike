const express = require('express');
const sqlite3 = require('sqlite3');
const xlsx = require('xlsx'); 
const fs = require('fs');

const app = express();
const port = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Создаем соединение с базой данных (создает файл, если его нет)
const db = new sqlite3.Database('./coffelike.db', (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Соединение с базой данных установлено.');

  // Создаем таблицу (если ее нет)
  db.run(`
    CREATE TABLE IF NOT EXISTS applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vacancy TEXT,
      fio TEXT,
      citizenship TEXT,
      city TEXT,
      telegram TEXT,
      phone TEXT,
      age INTEGER,
      education TEXT,
      experience TEXT,
      reason TEXT,
      schedule TEXT,
      salary INTEGER,
      period TEXT,
      area TEXT,
      source TEXT
    )
  `, (err) => {
    if (err) {
      console.error(err.message);
    }
    console.log('Таблица "applications" создана или уже существует.');
  });
});

// Обработчик POST-запроса для добавления ответа
app.post('/add-response', (req, res) => {
  const { 
    vacancy, 
    fio, 
    citizenship, 
    city, 
    telegram, 
    phone, 
    age, 
    education, 
    experience, 
    reason, 
    schedule, 
    salary, 
    period, 
    area, 
    source 
  } = req.body;

  // Вставляем данные в таблицу "applications"
  const insertSql = `
    INSERT INTO applications (
      vacancy,
      fio,
      citizenship,
      city,
      telegram,
      phone,
      age,
      education,
      experience,
      reason,
      schedule,
      salary,
      period,
      area,
      source
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )
  `;
  const values = [
    vacancy, fio, citizenship, city, telegram, phone, age, education, experience, reason, schedule, salary, period, area, source
  ];

  db.run(insertSql, values, function (err) {
    if (err) {
      console.error("Ошибка при добавлении ответа в базу данных:", err);
      res.status(500).json({ message: 'Ошибка при добавлении ответа' });
    } else {
      console.log("Ответ успешно добавлен в базу данных!");
      
    }
    // Закрываем соединение с базой данных
    // db.close();
  });
});


// Обработчик GET-запроса для скачивания таблицы
app.get('/download', (req, res) => {
  db.all('SELECT * FROM applications', (err, rows) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Ошибка при чтении данных из базы данных');
      return;
    }

    // Преобразование данных в Excel-рабочую книгу
    const workbook = xlsx.utils.book_new();
    const worksheet = xlsx.utils.json_to_sheet(rows);
    xlsx.utils.book_append_sheet(workbook, worksheet, 'Applications'); 

    // Создание буфера для Excel-файла
    const buffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });

    // Установка заголовков для скачивания Excel-файла
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=applications.xlsx');

    // Отправка Excel-файла в ответ
    res.send(buffer);
  });
});

// Обработчик GET-запроса для корневого маршрута ('/')
// app.get('/', (req, res) => {
//   res.sendFile(__dirname + '/public/html/'); // Отправляем файл index.html
// });

// Сервировка статического файла (index.html)
app.use(express.static('public'));

// Запуск сервера
app.listen(port, () => {
  console.log(`Сервер запущен на порту ${port}`);
});