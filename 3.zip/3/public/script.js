/* jshint esversion:8 */

// Fetch words from animals.json
async function fetchAnimalsWords() {
  const response = await fetch("/animals.json");
  const data = await response.json();
  return data.animals;
}

let myWordsFromJson = []; // Массив для хранения слов
let wordsUsed = []; // Массив для отслеживания использованных слов

// Function to scramble a word
function scrambleWord(word) {
  let letters = word.split('');
  for (let i = letters.length - 1; i > 0; i--) {
    let j = Math.floor(Math.random() * (i + 1));
    [letters[i], letters[j]] = [letters[j], letters[i]]; 
  }
  return letters.join('');
}

// Game variables
let currentWord = "";
let correctCount = 0;
let incorrectCount = 0;
let round = 0;

// Get HTML elements
const wordDisplay = document.getElementById("word-display");
const answerInput = document.getElementById("answer-input");
const answerButton = document.getElementById("answer-button");
const correctCountSpan = document.getElementById("correct-count");
const incorrectCountSpan = document.getElementById("incorrect-count");
const startGameButton = document.getElementById("start-game");
const restartButton = document.getElementById("restart-button");

// Event listeners
startGameButton.addEventListener("click", startGame);
answerButton.addEventListener("click", checkAnswer);
restartButton.addEventListener("click", () => {
  // Переход на index.html
  window.location.href = "quize.html"; 
});

// Start game function
async function startGame() {
  correctCount = 0;
  incorrectCount = 0;
  round = 0;
  wordsUsed = []; // Сбрасываем массив использованных слов

  correctCountSpan.textContent = correctCount;
  incorrectCountSpan.textContent = incorrectCount;

  // Load words from animals.json
  myWordsFromJson = await fetchAnimalsWords();

  // Hide Start Game button and show word display elements
  startGameButton.style.display = "none";
  wordDisplay.style.display = "block";

  // Start the first round
  nextRound();
}

// Next round function
function nextRound() {
  round++;
  answerInput.value = ""; // Clear the input field

  // Check if all rounds are completed
  if (round > 5) {
    // Display game results and show Restart button
    wordDisplay.style.display = "none";
    answerInput.style.display = "none";
    answerButton.style.display = "none";
    restartButton.style.display = "block";

    // Display results
    alert(`Результат: ${correctCount} из 5`);
    return; 
  }

  // Select a random word that hasn't been used yet
  let randomIndex;
  do {
    randomIndex = Math.floor(Math.random() * myWordsFromJson.length);
  } while (wordsUsed.includes(randomIndex));

  wordsUsed.push(randomIndex); // Add the used word to the array
  currentWord = myWordsFromJson[randomIndex];

  // Scramble the word
  const scrambledWord = scrambleWord(currentWord);

  // Display the scrambled word
  wordDisplay.textContent = scrambledWord;

  // Show the answer input and button only from the first round
  if (round === 1) {
    answerInput.style.display = "block";
    answerButton.style.display = "block";
  }
}

// Check answer function
function checkAnswer() {
  const userAnswer = answerInput.value.toLowerCase();

  if (userAnswer === currentWord.toLowerCase()) {
    correctCount++;
    correctCountSpan.textContent = correctCount;
  } else {
    incorrectCount++;
    incorrectCountSpan.textContent = incorrectCount;
  }

  // Go to the next round
  nextRound();
}